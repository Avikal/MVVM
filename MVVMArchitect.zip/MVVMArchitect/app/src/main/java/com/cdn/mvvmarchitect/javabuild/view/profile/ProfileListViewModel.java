package com.cdn.mvvmarchitect.javabuild.view.profile;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;
import android.content.Intent;
import com.cdn.mvvmarchitect.javabuild.data.MVVMRepository;
import com.cdn.mvvmarchitect.javabuild.data.model.ProductMainResponse;
import com.cdn.mvvmarchitect.javabuild.util.LogUtil;
import com.cdn.mvvmarchitect.javabuild.view.activity.SplashActivity;
import com.cdn.mvvmarchitect.javabuild.view.login.LoginActivity;
import com.cdn.mvvmarchitect.javabuild.viewmodles.BaseViewModel;
import com.test.contactapp.di.scope.ActivityScope;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

import javax.inject.Inject;
import java.util.List;
import java.util.Map;

@ActivityScope
public class ProfileListViewModel extends BaseViewModel {

    public MVVMRepository repository;

    @Inject
    public ProfileListViewModel(MVVMRepository repository) {
        this.repository = repository;
    }


    public final MutableLiveData<ProductMainResponse> responseLiveData = new MutableLiveData<>();

    public void fetchNewId() {
        liveDataIsLoading.setValue(true);
        disposable.add(repository.getNewsId()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<List<Integer>>() {
                               @Override
                               public void accept(List<Integer> integers) throws Exception {
                                   liveDataIsLoading.setValue(false);
                                   for (int i = 0; i < integers.size(); i++) {
                                       LogUtil.e("Value", " " + integers.size());
                                   }
                               }
                           },
                        new Consumer<Throwable>() {
                            @Override
                            public void accept(Throwable throwable) throws Exception {

                            }
                        }));
    }

    public void fetchProductData() {
        liveDataIsLoading.setValue(true);
        disposable.add(repository.getProductList("01.12.2018", "31.03.2019", "asc")
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new Consumer<Disposable>() {
                    @Override
                    public void accept(Disposable d) throws Exception {
                        liveDataIsLoading.setValue(true);
                    }
                })
                .subscribe(new Consumer<ProductMainResponse>() {
                               @Override
                               public void accept(ProductMainResponse result) throws Exception {
                                   liveDataIsLoading.setValue(false);
                                   List<ProductMainResponse.Mission> as = result.getMissions();
                                   responseLiveData.setValue(result);
                               }
                           },
                        new Consumer<Throwable>() {
                            @Override
                            public void accept(Throwable throwable) throws Exception {
                                liveDataIsLoading.setValue(false);
                                preferenceUtil.setLoggedIn(false);
                                doCheckError(throwable, true, 1);

                            }
                        }));
    }
}
