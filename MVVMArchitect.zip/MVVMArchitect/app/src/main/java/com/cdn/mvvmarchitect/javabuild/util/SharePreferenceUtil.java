package com.cdn.mvvmarchitect.javabuild.util;

import android.content.SharedPreferences;
import com.cdn.mvvmarchitect.javabuild.data.model.User;
import com.google.gson.Gson;

public class SharePreferenceUtil {

    private SharedPreferences preferences;
    private Gson gson;
    private SharedPreferences.Editor editor;

    public String access_token = "";
    public String refresh_token = "";
    public boolean isLoginExist = false;
    public User loggedUser;

    public static String ACCESS_TOKEN = "ACCESS_TOKEN";
    public static String IS_LOGGEDIN = "IS_LOGGEDIN";
    public static String USER = "USER";


    public SharePreferenceUtil(SharedPreferences preferences, Gson gson) {
        this.preferences = preferences;
        this.gson = gson;
    }

    public void loadValues() {
        isLoginExist = isLoginSessionExist();
        loggedUser = getUser();
        access_token = getAccessToken();
        refresh_token = getRefreshToken();
    }

    public String getAccessToken() {
        return preferences.getString(ACCESS_TOKEN, "");
    }

    public void setAccessToken(String access_token) {
        this.access_token = access_token;
        putString(ACCESS_TOKEN, access_token);
    }

    public String getRefreshToken() {
        return preferences.getString(ACCESS_TOKEN, "");
    }

    public void setRefreshToken(String refresh_token) {
        this.refresh_token = refresh_token;

    }

    public void setLoggedIn(boolean isLoginExist) {
        this.isLoginExist = isLoginExist;
        putBoolean(IS_LOGGEDIN, isLoginExist);
    }

    public boolean getBoolean(String prefName, boolean prfValue) {
        return preferences.getBoolean(prefName, prfValue);
    }

    public boolean isLoginSessionExist() {
        return getBoolean(IS_LOGGEDIN, isLoginExist);
    }

    public void setLoggedUser(User user) {
        this.loggedUser = user;
        editor = preferences.edit();
        editor.putString(USER, gson.toJson(loggedUser, User.class));
        editor.apply();
    }

    private User getUser() {
        String userStr = preferences.getString(USER, "");
        if (userStr.length() > 0) {
            return gson.fromJson(userStr, User.class);
        }
        return null;
    }

    protected void putString(String name, String value) {
        editor = preferences.edit();
        editor.putString(name, value);
        editor.apply();
    }

    protected void putBoolean(String name, boolean value) {
        editor = preferences.edit();
        editor.putBoolean(name, value);
        editor.apply();
    }


    public void clearAllPreference() {
        isLoginExist =false;
        preferences.edit().clear().apply();
    }
}
