package com.cdn.mvvmarchitect.javabuild.data.model;

import java.io.Serializable;

public class Coin implements Serializable {
}
