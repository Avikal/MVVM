package com.cdn.mvvmarchitect.javabuild.view.news;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import com.cdn.mvvmarchitect.MVVMApp;
import com.cdn.mvvmarchitect.R;
import com.cdn.mvvmarchitect.databinding.ActivityNewsBinding;
import com.cdn.mvvmarchitect.javabuild.data.model.NewsResponse;
import com.cdn.mvvmarchitect.javabuild.di.component.ActivityComponent;
import com.cdn.mvvmarchitect.javabuild.di.component.DaggerActivityComponent;
import com.cdn.mvvmarchitect.javabuild.di.module.CustActivityModule;
import com.cdn.mvvmarchitect.javabuild.util.AppAlertLoaderDialog;
import com.cdn.mvvmarchitect.javabuild.util.LogUtil;
import com.cdn.mvvmarchitect.javabuild.view.activity.BaseActivity;
import com.cdn.mvvmarchitect.javabuild.view.login.LoginActivity;
import com.cdn.mvvmarchitect.javabuild.view.profile.ProfileListViewModel;
import com.cdn.mvvmarchitect.javabuild.viewmodles.ViewModelFactory;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class NewsActivity extends BaseActivity {

    private ActivityNewsBinding binding;

    @Inject
    ViewModelFactory<NewsViewModel> mFactory;

    @Inject
    public AppAlertLoaderDialog appAlertLoaderDialog;

    public NewsViewModel viewModel;

    ActivityComponent component;

    private NewsAdapter adapter;

    ArrayList<NewsResponse> newsList = new ArrayList<>();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this,
                R.layout.activity_news);

        component = DaggerActivityComponent.builder().custActivityModule(new CustActivityModule(this))
                .appComponent(((MVVMApp) getApplication()).getAppComponent()).build();
        component.inject(this);
        viewModel = ViewModelProviders.of(this, mFactory).get(NewsViewModel.class);
        adapter = new NewsAdapter(NewsActivity.this, newsList);
        binding.recycleViewNews.setAdapter(adapter);
        viewModel.fetchNewsIdTest();


        viewModel.newsData.observe(this, new Observer<ArrayList<NewsResponse>>() {
            @Override
            public void onChanged(@Nullable ArrayList<NewsResponse> newsResponses) {
                newsList.clear();
                newsList.addAll(newsResponses);
                adapter.notifyDataSetChanged();
            }
        });

        viewModel.liveDataIsLoading.observe(this, new Observer() {
            @Override
            public void onChanged(@Nullable Object o) {


                if (NewsActivity.this.isFinishing()) {
                    return;
                }
                if ((Boolean) o) {
                    appAlertLoaderDialog.start();
                } else {
                    appAlertLoaderDialog.stop();
                }
            }
        });

        setPullToRefresh();
    }

    public void setPullToRefresh() {
        binding.swipeContainerNews.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                binding.swipeContainerNews.setRefreshing(false);
                viewModel.fetchNewsIdTest();
                binding.swipeContainerNews.setColorSchemeResources(android.R.color.holo_blue_bright,

                        android.R.color.holo_green_light,

                        android.R.color.holo_orange_light,

                        android.R.color.holo_red_light);
            }
        });
    }
}
