package com.cdn.mvvmarchitect.javabuild.util;

import android.arch.lifecycle.LiveData;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import com.test.contactapp.di.scope.ActivityScope;

import javax.inject.Inject;


@ActivityScope
public class ConnectionLiveData extends LiveData<ConnectionModel> {

    private Context context;

    @Inject
    public ConnectionLiveData(Context context) {
        this.context = context;
    }

    private BroadcastReceiver networkReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            LogUtil.e("ConnectionLiveData", "Connection Live Data");
            if (intent.getExtras() != null) {
                NetworkInfo activeNetwork = (NetworkInfo) intent.getExtras().get(ConnectivityManager.EXTRA_NETWORK_INFO);
                boolean isConnected = activeNetwork != null && activeNetwork.isConnectedOrConnecting();
                if (isConnected) {
                    switch (activeNetwork.getType()) {
                        case ConnectivityManager.TYPE_WIFI:
                            ConnectionLiveData.this.setValue(new ConnectionModel(1, true));
                            break;
                        case ConnectivityManager.TYPE_MOBILE:
                            ConnectionLiveData.this.setValue(new ConnectionModel(2, true));
                    }
                } else {
                    ConnectionLiveData.this.setValue(new ConnectionModel(0, false));
                }
            }
        }
    };

    @Override
    public void onActive() {
        super.onActive();
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        context.registerReceiver(networkReceiver, filter);
    }

    @Override
    public void onInactive() {
        super.onInactive();
        context.unregisterReceiver(networkReceiver);
    }
}
