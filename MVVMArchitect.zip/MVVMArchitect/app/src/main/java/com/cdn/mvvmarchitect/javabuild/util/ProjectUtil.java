package com.cdn.mvvmarchitect.javabuild.util;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.widget.Toast;
import com.cdn.mvvmarchitect.MVVMApp;
import com.cdn.mvvmarchitect.R;
import org.json.JSONObject;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.text.SimpleDateFormat;
import java.util.Date;

@Singleton
public class ProjectUtil {

    public Context appContext;
    public SharePreferenceUtil sharePreferenceUtil;

    @Inject
    public ProjectUtil(Context appContext, SharePreferenceUtil sharePreferenceUtil) {
        this.appContext = appContext;
        this.sharePreferenceUtil = sharePreferenceUtil;
    }

    public void showToast(int id) {
        Toast.makeText(((MVVMApp) appContext), id, Toast.LENGTH_SHORT).show();
    }

    public boolean checkNetwork() {
        ConnectivityManager connectivityManager = (ConnectivityManager) appContext.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    public String getApiErrorMsg(int id) {
        return appContext.getResources().getString(id);
    }

    public void getApiMessage(JSONObject apiStatus) {
        try {
            int resId = this.appContext.getResources().getIdentifier("status_" + apiStatus.get("status"), "string", this.appContext.getPackageName());
            Toast.makeText(this.appContext, (CharSequence) this.appContext.getString(resId), Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(appContext, appContext.getString(R.string.general_error_message), Toast.LENGTH_SHORT).show();
        }


    }

    public void showToast(String message) {
        Toast.makeText(((MVVMApp) appContext), message, Toast.LENGTH_SHORT).show();
    }

    public static String formatTimeForDisplay(String dateTime) {
        SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        SimpleDateFormat outputFormat = new SimpleDateFormat("HH:mm");
        String date = inputFormat.format(dateTime);
        String outPutDate = outputFormat.format(date);
        return outPutDate;
    }

    public void logout() {
        sharePreferenceUtil.clearAllPreference();
        ((MVVMApp) appContext).logout();
    }
}
