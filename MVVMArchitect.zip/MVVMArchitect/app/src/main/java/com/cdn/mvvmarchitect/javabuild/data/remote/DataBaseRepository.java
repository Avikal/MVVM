package com.cdn.mvvmarchitect.javabuild.data.remote;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Room;
import android.content.Context;
import android.os.AsyncTask;
import com.cdn.mvvmarchitect.javabuild.data.model.NewsResponse;

import java.util.List;

public class DataBaseRepository {

    private String DB_NAME = "db_task";

    private NewsResponseDatabase noteDatabase;

    public DataBaseRepository(Context context) {
        noteDatabase = Room.databaseBuilder(context, NewsResponseDatabase.class, DB_NAME).build();
    }

  /*  public void insertTask(String by, Integer descendants, Integer id, List<Integer> kids,
                           Integer score, Integer time, String title, String type, String url) {

        insertTask(by, descendants, id, kids, score, time, title, type, url);
    }*/


    public void insertTask(String by, Integer descendants, Integer id, List<Integer> kids,
                           Integer score, Integer time, String title, String type, String url) {

        NewsResponse newsResponse = new NewsResponse();
        newsResponse.setBy(by);
        newsResponse.setTitle(title);
        newsResponse.setKids(kids);
        newsResponse.setScore(score);
        newsResponse.setTime(time);
        newsResponse.setTitle(title);
        newsResponse.setType(type);
        newsResponse.setUrl(url);

        insertTask(newsResponse);
    }

    public void insertTask(final NewsResponse note) {
        new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... voids) {
                noteDatabase.daoAccess().insertTask(note);
                return null;
            }
        }.execute();
    }


    public LiveData<NewsResponse> getTask(int id) {
        return noteDatabase.daoAccess().getTask(id);
    }

    public LiveData<List<NewsResponse>> getTasks() {
        return noteDatabase.daoAccess().fetchAllTasks();
    }
}
