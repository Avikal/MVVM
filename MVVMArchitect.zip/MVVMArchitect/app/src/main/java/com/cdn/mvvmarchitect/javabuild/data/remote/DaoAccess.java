package com.cdn.mvvmarchitect.javabuild.data.remote;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import com.cdn.mvvmarchitect.javabuild.data.model.NewsResponse;

import java.util.List;

@Dao
public interface DaoAccess {

    @Insert
    Long insertTask(NewsResponse newsResponse);

    @Query("SELECT * FROM NewsResponse ORDER BY score desc")
    LiveData<List<NewsResponse>> fetchAllTasks();

    @Query("SELECT * FROM NewsResponse WHERE id =:taskId")
    LiveData<NewsResponse> getTask(int taskId);
}
