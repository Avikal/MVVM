package com.cdn.mvvmarchitect.javabuild.data.model;

public class LoginResponse {
}
