package com.cdn.mvvmarchitect.javabuild.data;


import android.arch.lifecycle.LiveData;
import com.cdn.mvvmarchitect.javabuild.data.model.NewsResponse;
import com.cdn.mvvmarchitect.javabuild.data.model.ProductMainResponse;
import com.cdn.mvvmarchitect.javabuild.data.model.ResponseUserDetail;
import com.cdn.mvvmarchitect.javabuild.data.model.request.LoginRequest;
import com.cdn.mvvmarchitect.javabuild.data.remote.ApiInterface;
import com.cdn.mvvmarchitect.javabuild.data.remote.DataBaseRepository;
import com.cdn.mvvmarchitect.javabuild.util.SharePreferenceUtil;
import com.google.gson.JsonObject;
import io.reactivex.Observable;

import java.util.List;
import java.util.Map;


public class MVVMRepository implements IRepository {


    ApiInterface apiInterface;
    SharePreferenceUtil sharePreferenceUtil;
    DataBaseRepository dataBaseRepository;
    String authToken = null;

    public MVVMRepository(ApiInterface apiInterface, SharePreferenceUtil sharePreferenceUtil,
                          DataBaseRepository dataBaseRepository) {
        this.apiInterface = apiInterface;
        this.sharePreferenceUtil = sharePreferenceUtil;
        this.dataBaseRepository = dataBaseRepository;
    }


    @Override
    public Observable<ProductMainResponse> getProductList(String start, String end, String sort) {
        return apiInterface.getFrontPageCoinData(header(), start, end, sort);
    }

    @Override
    public Observable<JsonObject> login(LoginRequest loginRequest) {
        return apiInterface.getLoginData(loginRequest);
    }

    @Override
    public Observable<ResponseUserDetail> fetchUserData(String header) {
        return apiInterface.fetchUserData(header);
    }

    public String header() {
        authToken = "Bearer " + sharePreferenceUtil.access_token;
        return authToken;
    }


    @Override
    public Observable<JsonObject> getRefreshToken(LoginRequest loginRequest) {
        return apiInterface.getRefreshToken(header(), loginRequest);
    }

    @Override
    public Observable<List<Integer>> getNewsId() {
        return apiInterface.getNewsId();
    }

    @Override
    public Observable<NewsResponse> getNewsStory(int id) {
        return apiInterface.getNewsStories(id);
    }

    public LiveData<List<NewsResponse>> getOfflineNews() {
        return dataBaseRepository.getTasks();
    }

}
