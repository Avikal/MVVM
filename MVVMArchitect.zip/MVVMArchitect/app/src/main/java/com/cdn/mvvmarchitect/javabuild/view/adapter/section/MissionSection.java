package com.cdn.mvvmarchitect.javabuild.view.adapter.section;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;
import com.cdn.mvvmarchitect.R;
import com.cdn.mvvmarchitect.javabuild.data.model.ProductMainResponse;
import com.cdn.mvvmarchitect.javabuild.util.ProjectUtil;
import com.cdn.mvvmarchitect.javabuild.view.profile.OnMissionItemClick;


import java.util.List;


public class MissionSection extends StatelessSection {

    String title;
    List<ProductMainResponse.Mission> list;
    Context context;
    OnMissionItemClick onItemClick;

    public MissionSection(Context context, String title, List<ProductMainResponse.Mission> list, OnMissionItemClick onItemClick) {
        super(SectionParameters.builder()
                .itemResourceId(R.layout.section_ex1_item)
                .headerResourceId(R.layout.section_ex1_header)
                .build());

        this.title = title;
        this.list = list;
        this.context = context;
        this.onItemClick = onItemClick;
    }

    @Override
    public int getContentItemsTotal() {
        return list.size();
    }

    @Override
    public RecyclerView.ViewHolder getItemViewHolder(View view) {
        return new ItemViewHolder(view);
    }

    @Override
    public void onBindItemViewHolder(RecyclerView.ViewHolder holder, int position) {
        final ItemViewHolder itemHolder = (ItemViewHolder) holder;

        final ProductMainResponse.Mission mission = list.get(position);
        itemHolder.textview_title.setText("" + mission.getMarket().getName());
        String strStartTime = ProjectUtil.formatTimeForDisplay(mission.getStart());
        String strEndTime = ProjectUtil.formatTimeForDisplay(mission.getEnd());
        itemHolder.textview_subtitle.setText(strStartTime + "-" + strEndTime);
        itemHolder.profile.setText(mission.getType().substring(0, 1));

        itemHolder.rootView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onItemClick != null) {
                    onItemClick.onClick(mission);
                }
            }
        });
    }

    @Override
    public RecyclerView.ViewHolder getHeaderViewHolder(View view) {
        return new HeaderViewHolder(view);
    }

    @Override
    public void onBindHeaderViewHolder(RecyclerView.ViewHolder holder) {
        HeaderViewHolder headerHolder = (HeaderViewHolder) holder;

        headerHolder.tvTitle.setText(title);
    }
}


class HeaderViewHolder extends RecyclerView.ViewHolder {

    final TextView tvTitle;

    HeaderViewHolder(View view) {
        super(view);

        tvTitle = (TextView) view.findViewById(R.id.tvTitle);
    }
}

class ItemViewHolder extends RecyclerView.ViewHolder {

    final View rootView;

    final TextView profile;
    final TextView textview_title;
    final TextView textview_subtitle;


    ItemViewHolder(View view) {
        super(view);

        rootView = view;
        profile = (TextView) view.findViewById(R.id.textview_word);
        textview_title = (TextView) view.findViewById(R.id.textview_title);
        textview_subtitle = (TextView) view.findViewById(R.id.textview_subtitle);

    }
}

