package com.cdn.mvvmarchitect.javabuild.di.component;

import android.content.Context;
import com.cdn.mvvmarchitect.javabuild.data.remote.DataBaseRepository;
import com.cdn.mvvmarchitect.javabuild.di.module.CustActivityModule;
import com.cdn.mvvmarchitect.javabuild.util.ConnectionLiveData;
import com.cdn.mvvmarchitect.javabuild.util.SharePreferenceUtil;
import com.cdn.mvvmarchitect.javabuild.view.news.NewsActivity;
import com.cdn.mvvmarchitect.javabuild.view.profile.ProfileListActivity;
import com.cdn.mvvmarchitect.javabuild.view.activity.SplashActivity;
import com.cdn.mvvmarchitect.javabuild.view.login.LoginActivity;
import com.test.contactapp.di.scope.ActivityScope;
import dagger.Component;

@Component(dependencies = AppComponent.class, modules = {CustActivityModule.class
})
@ActivityScope
public interface ActivityComponent {

    SharePreferenceUtil sharePrefUtil();

    DataBaseRepository dataBaseRepo();

    ConnectionLiveData connectionLiveData();

    Context context();

    void inject(SplashActivity splashActivity);

    void inject(LoginActivity loginActivity);

    void inject(ProfileListActivity profileListActivity);

    void inject(NewsActivity newsActivity);

}


