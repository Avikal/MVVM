package com.cdn.mvvmarchitect.javabuild.data.remote;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.RoomDatabase;
import com.cdn.mvvmarchitect.javabuild.data.model.NewsResponse;

@Database(entities = {NewsResponse.class}, version = 1, exportSchema = false)
public abstract class NewsResponseDatabase extends RoomDatabase {

    public abstract DaoAccess daoAccess();
}
