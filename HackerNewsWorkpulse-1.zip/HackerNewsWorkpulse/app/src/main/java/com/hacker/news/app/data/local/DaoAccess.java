package com.hacker.news.app.data.local;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;
import com.hacker.news.app.data.model.NewsResponse;

import java.util.List;

@Dao
public interface DaoAccess {


    /**
     * For database Dao
     *
     * @param newsResponse
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertNews(NewsResponse newsResponse);

    @Query("SELECT * FROM news ORDER BY score desc")
    List<NewsResponse> fetchAllNews();

    @Query("SELECT * FROM news WHERE id =:newsId")
    LiveData<NewsResponse> getNews(int newsId);
}
