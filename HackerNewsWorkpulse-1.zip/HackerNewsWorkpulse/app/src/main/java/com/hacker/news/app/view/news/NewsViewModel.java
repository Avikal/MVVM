package com.hacker.news.app.view.news;

import android.arch.lifecycle.MutableLiveData;
import com.hacker.news.app.data.MVVMRepository;
import com.hacker.news.app.data.model.NewsResponse;
import com.hacker.news.app.util.LogUtil;
import com.hacker.news.app.viewmodles.BaseViewModel;
import io.reactivex.Observable;
import io.reactivex.ObservableSource;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Action;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;
import io.reactivex.schedulers.Schedulers;

import javax.inject.Inject;
import java.util.*;

public class NewsViewModel extends BaseViewModel {

    public MVVMRepository repository;


    @Inject
    public NewsViewModel(MVVMRepository repository) {
        this.repository = repository;
    }

    public final MutableLiveData<List<Integer>> newsIdData = new MutableLiveData<>();

    public MutableLiveData<ArrayList<NewsResponse>> newsData = new MutableLiveData<>();

    public ArrayList<NewsResponse> newsList = new ArrayList<>();

    public ArrayList<Integer> commonIds = new ArrayList<>();

    public int count = 50;

    /**
     * Fetch the news id and news Detail
     */
    public void fetchNewsIdTest() {
        liveDataIsLoading.setValue(true);
        newsList.clear();
        if (projectUtil.checkNetwork()) {
            disposable.add(repository.getNewsId()
                    .flatMap(new Function<List<Integer>, ObservableSource<Integer>>() {
                        @Override
                        public ObservableSource<Integer> apply(List<Integer> tickets) throws Exception {
                            LogUtil.e("NewSId ", " " + tickets.size());
                            count = count + commonIds.size();
                            for (int i = commonIds.size(); i < count; i++) {
                                commonIds.add(tickets.get(i));
                            }

                            return Observable.fromIterable(commonIds);
                        }
                    }).flatMap(new Function<Integer, ObservableSource<NewsResponse>>() {
                        @Override
                        public ObservableSource<NewsResponse> apply(Integer integer) throws Exception {
                            return repository.getNewsStory(integer);
                        }
                    }).map(new Function<NewsResponse, NewsResponse>() {
                        @Override
                        public NewsResponse apply(NewsResponse newsResponse) throws Exception {

                            saveNewsInDB(newsResponse);
                            return newsResponse;
                        }
                    })
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(new Consumer<NewsResponse>() {
                        @Override
                        public void accept(NewsResponse newsResponse) throws Exception {

                            newsList.add(newsResponse);

                        }


                    }, new Consumer<Throwable>() {
                        @Override
                        public void accept(Throwable throwable) throws Exception {

                        }
                    }, new Action() {
                        @Override
                        public void run() throws Exception {
                            LogUtil.e("NewSId ", " " + newsList.size());
                            Set<NewsResponse> s = new HashSet<NewsResponse>();
                            s.addAll(newsList);
                            newsList.clear();
                            newsList.addAll(s);
                            Collections.sort(newsList);
                            newsData.setValue(newsList);
                            liveDataIsLoading.setValue(false);
                        }
                    }));
        } else {
            disposable.add(repository.getOfflineData()
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(new Consumer<List<NewsResponse>>() {
                        @Override
                        public void accept(List<NewsResponse> newsResponses) throws Exception {
                            Set<NewsResponse> s = new HashSet<NewsResponse>();
                            s.addAll(newsList);
                            newsList.clear();
                            newsList.addAll(s);
                            Collections.sort(newsList);
                            newsData.setValue(newsList);
                            liveDataIsLoading.setValue(false);
                        }
                    }));
        }


    }

    /**
     * Sava data in local database
     *
     * @param newsResponse
     */
    public void saveNewsInDB(NewsResponse newsResponse) {

        repository.insertNews(newsResponse);
//        disposable.add(
//                .subscribeOn(Schedulers.io())
//                .observeOn(AndroidSchedulers.mainThread())
//                .subscribe(new Consumer<Boolean>() {
//                    @Override
//                    public void accept(Boolean aBoolean) throws Exception {
//
//                    }
//                }));

    }


}
