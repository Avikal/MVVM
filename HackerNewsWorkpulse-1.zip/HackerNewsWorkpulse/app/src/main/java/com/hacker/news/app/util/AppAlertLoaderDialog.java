package com.hacker.news.app.util;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.drawable.ColorDrawable;
import android.view.Window;
import android.view.WindowManager;
import com.hacker.news.app.R;
import com.test.contactapp.di.scope.ActivityScope;
import com.wang.avi.AVLoadingIndicatorView;

import javax.inject.Inject;

@ActivityScope
public class AppAlertLoaderDialog extends Dialog {
    private final Activity mContext;
    AVLoadingIndicatorView avi;

    /**
     * public constructor
     *
     * @param context -- holds the context from where the dialog is initated
     */
    @Inject
    public AppAlertLoaderDialog(Activity context) {
        super(context, R.style.NewDialog);
        this.mContext = context;
        initDialog();
    }

    /**
     * \
     * initiate dialog
     *
     * @param -- string message
     */

    private void initDialog() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        if (getWindow() != null) {
            getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

            setContentView(R.layout.dialog_alert_loader);

        }
        setCancelable(false);
        avi = findViewById(R.id.loader);
    }

    /**
     * Start the loader dialog
     */
    public void start() {
        try {
            avi.smoothToShow();
            show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * End the loader dialog
     */
    public void stop() {
        try {
            avi.smoothToHide();
            dismiss();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}