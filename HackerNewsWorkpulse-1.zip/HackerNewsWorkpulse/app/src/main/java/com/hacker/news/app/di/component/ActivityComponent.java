package com.hacker.news.app.di.component;

import android.content.Context;
import com.hacker.news.app.data.local.DaoAccess;
import com.hacker.news.app.di.module.CustActivityModule;
import com.hacker.news.app.util.ConnectionLiveData;
import com.hacker.news.app.util.SharePreferenceUtil;
import com.hacker.news.app.view.news.NewsActivity;
import com.hacker.news.app.view.SplashActivity;
import com.test.contactapp.di.scope.ActivityScope;
import dagger.Component;

@Component(dependencies = AppComponent.class, modules = {CustActivityModule.class})
@ActivityScope
public interface ActivityComponent {

    SharePreferenceUtil sharePrefUtil();

    ConnectionLiveData connectionLiveData();

    Context context();

    DaoAccess getDao();

    void inject(SplashActivity splashActivity);

    void inject(NewsActivity newsActivity);

}


