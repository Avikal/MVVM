package com.hacker.news.app.di.component;

import android.content.Context;
import com.hacker.news.HackerApp;
import com.hacker.news.app.data.MVVMRepository;
import com.hacker.news.app.data.remote.ApiInterface;
import com.hacker.news.app.data.local.DaoAccess;
import com.hacker.news.app.di.module.AppModule;
import com.hacker.news.app.di.module.NetModule;
import com.hacker.news.app.util.SharePreferenceUtil;

import dagger.Component;

import javax.inject.Singleton;

@Component(modules = {AppModule.class,
        NetModule.class
})
@Singleton
public interface AppComponent {

    MVVMRepository repository();

    SharePreferenceUtil sharePrefUtil();

    Context context();

    void inject(HackerApp mvvmApp);

    void inject(ApiInterface apiInterface);

    DaoAccess getDao();

}


