package com.hacker.news.app.data;


import android.util.Log;
import com.hacker.news.app.data.local.DaoAccess;
import com.hacker.news.app.data.model.NewsResponse;
import com.hacker.news.app.data.remote.ApiInterface;
import com.hacker.news.app.util.SharePreferenceUtil;
import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;

import java.util.List;


/**
 * Define the api calling & the get the response of the api
 */

public class MVVMRepository implements IRepository {


    private static final String TAG = "MVVMRepository";
    ApiInterface apiInterface;
    SharePreferenceUtil sharePreferenceUtil;
    DaoAccess daoAccess;
    String authToken = null;

    public MVVMRepository(ApiInterface apiInterface, SharePreferenceUtil sharePreferenceUtil,
                          DaoAccess daoAccess) {
        this.apiInterface = apiInterface;
        this.sharePreferenceUtil = sharePreferenceUtil;
        this.daoAccess = daoAccess;
    }

    /**
     * Method of calling the api for getting news Id
     *
     */

    @Override
    public Observable<List<Integer>> getNewsId() {
        return apiInterface.getNewsId();
    }

    /**
     * Getting news Detail
     * @param id newsID
     * @return NewResponse
     */
    @Override
    public Observable<NewsResponse> getNewsStory(int id) {
        return apiInterface.getNewsStories(id);
    }


    /**
     * Insert method to insert the news in local db
     * @param newsResponse
     * @return True or false
     */
    @Override
    public Boolean insertNews(NewsResponse newsResponse) {
        daoAccess.insertNews(newsResponse);
        Log.e(TAG, "insertNews: " );
            return  true;
//        return Observable.create(new ObservableOnSubscribe<Boolean>() {
//            @Override
//            public void subscribe(ObservableEmitter<Boolean> emitter) throws Exception {
//                emitter.onNext(true);
//                emitter.onComplete();
//            }
//        });
    }

    /**
     * Getting the News data in offline mode
     * @return List of news
     */
    @Override
    public Observable<List<NewsResponse>> getOfflineData() {
        return Observable.create(new ObservableOnSubscribe<List<NewsResponse>>() {
            @Override
            public void subscribe(ObservableEmitter<List<NewsResponse>> emitter) throws Exception {
                List<NewsResponse> newsList = daoAccess.fetchAllNews();
                if (newsList == null) {
                    emitter.onComplete();

                } else {
                    emitter.onNext(newsList);
                    emitter.onComplete();
                }
            }
        });
    }


}
