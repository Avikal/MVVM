package com.hacker.news.app.view.news;

import android.content.Context;
import android.databinding.DataBindingUtil;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import com.hacker.news.app.R;
import com.hacker.news.app.data.model.NewsResponse;
import com.hacker.news.app.databinding.ItemNewsBinding;

import java.util.ArrayList;

public class NewsAdapter extends RecyclerView.Adapter<NewsAdapter.NewsHolder> {

    private Context context;
    private ArrayList<NewsResponse> newsList;
    private LayoutInflater inflater;

    public NewsAdapter(Context context, ArrayList<NewsResponse> newsList) {
        this.context = context;
        this.newsList = newsList;
        inflater = LayoutInflater.from(context);
    }

    @NonNull
    @Override
    public NewsHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        ItemNewsBinding binding = DataBindingUtil.inflate(inflater,
                R.layout.item_news, viewGroup, false);
        return new NewsHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull NewsHolder holder, int position) {
        NewsResponse newsResponse = newsList.get(position);
        holder.binding.textViewTitle.setText(newsResponse.getTitle());
        holder.binding.textViewScore.setText("" + newsResponse.getScore());
        holder.binding.textViewBy.setText("By:- " + newsResponse.getBy());
        holder.binding.textViewUrl.setText(newsResponse.getUrl());
    }

    @Override
    public int getItemCount() {
        if (newsList != null && newsList.size() > 0) {
            return newsList.size();
        } else {
            return 0;
        }
    }

    class NewsHolder extends RecyclerView.ViewHolder {

        public ItemNewsBinding binding;

        public NewsHolder(ItemNewsBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

}
