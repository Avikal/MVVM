package com.hacker.news.app.data;

import com.hacker.news.app.data.model.NewsResponse;
import io.reactivex.Observable;

import java.util.List;

/**
 * Repository for api calling
 */
interface IRepository {


    Observable<List<Integer>> getNewsId();

    Observable<NewsResponse> getNewsStory(int id);

    Boolean insertNews(NewsResponse newsResponse);

    Observable<List<NewsResponse>> getOfflineData();


}
