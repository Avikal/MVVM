package com.hacker.news;

import android.app.Application;
import android.content.Context;
import android.support.multidex.MultiDex;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import com.hacker.news.app.di.component.AppComponent;
import com.hacker.news.app.di.component.DaggerAppComponent;
import com.hacker.news.app.di.module.AppModule;
import com.hacker.news.app.di.module.NetModule;
import com.hacker.news.app.util.SharePreferenceUtil;

import javax.inject.Inject;

public class HackerApp extends Application {

    private static HackerApp instance;

    public static HackerApp getInstance() {
        return instance;
    }

    private static synchronized void setInstance(HackerApp app) {
        instance = app;
    }

    private AppComponent appComponent;

    @Inject
    public SharePreferenceUtil sharePreferenceUtil;

    @Override
    public void onCreate() {
        super.onCreate();
        setInstance(this);
        appComponent = DaggerAppComponent.builder()
                .appModule(new AppModule(this))
                .netModule(new NetModule("https://hacker-news.firebaseio.com/"))
                .build();
        appComponent.inject(this);
        sharePreferenceUtil.loadValues();
    }


    public AppComponent getAppComponent() {
        return appComponent;
    }


    /**
     * This method makes rotating loader animation on loading icon.
     */
    public void showLoadingAnimation(ImageView loadingImage) {
        RotateAnimation rotateAnimation = new RotateAnimation(0, 180,
                Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        rotateAnimation.setRepeatCount(Animation.INFINITE);
        rotateAnimation.setDuration(1000);
        loadingImage.setAnimation(rotateAnimation);
    }

    @Override
    protected void attachBaseContext(Context context) {
        super.attachBaseContext(context);
        MultiDex.install(context);
    }

}
