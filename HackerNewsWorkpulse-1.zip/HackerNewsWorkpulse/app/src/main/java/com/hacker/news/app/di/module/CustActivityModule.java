package com.hacker.news.app.di.module;

import android.app.Activity;
import dagger.Module;
import dagger.Provides;

@Module
public class CustActivityModule {

    private Activity activity;

    public CustActivityModule(Activity activity) {
        this.activity = activity;
    }

    @Provides
    public Activity getActivityContext() {
        return activity;
    }
}
