package com.hacker.news.app.view.news;

import android.app.AlertDialog;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.DialogInterface;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.view.View;
import com.hacker.news.HackerApp;
import com.hacker.news.app.R;
import com.hacker.news.app.data.model.NewsResponse;
import com.hacker.news.app.di.component.ActivityComponent;
import com.hacker.news.app.di.component.DaggerActivityComponent;
import com.hacker.news.app.di.module.CustActivityModule;
import com.hacker.news.app.util.AppAlertLoaderDialog;
import com.hacker.news.app.view.BaseActivity;
import com.hacker.news.app.viewmodles.ViewModelFactory;

import javax.inject.Inject;
import java.util.ArrayList;

import com.hacker.news.app.databinding.ActivityNewsBinding;

public class NewsActivity extends BaseActivity {

    private ActivityNewsBinding binding;

    @Inject
    ViewModelFactory<NewsViewModel> mFactory;

    @Inject
    public AppAlertLoaderDialog appAlertLoaderDialog;

    public NewsViewModel viewModel;

    ActivityComponent component;

    private NewsAdapter adapter;

    ArrayList<NewsResponse> newsList = new ArrayList<>();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this,
                R.layout.activity_news);

        component = DaggerActivityComponent.builder().custActivityModule(new CustActivityModule(this))
                .appComponent(((HackerApp) getApplication()).getAppComponent()).build();
        component.inject(this);
        viewModel = ViewModelProviders.of(this, mFactory).get(NewsViewModel.class);
        adapter = new NewsAdapter(NewsActivity.this, newsList);
        binding.recycleViewNews.setAdapter(adapter);
        viewModel.fetchNewsIdTest();

        setObserver();
        setPullToRefresh();
    }

    /**
     * Update the ui after data come from api
     */
    public void setObserver() {
        viewModel.newsData.observe(this, new Observer<ArrayList<NewsResponse>>() {
            @Override
            public void onChanged(@Nullable ArrayList<NewsResponse> newsResponses) {
                newsList.clear();
                newsList.addAll(newsResponses);
                if (newsList != null && newsList.size() > 0) {
                    binding.noDataFound.setVisibility(View.GONE);
                    binding.swipeContainerNews.setVisibility(View.VISIBLE);
                    adapter.notifyDataSetChanged();
                } else {
                    binding.noDataFound.setVisibility(View.VISIBLE);
                    binding.swipeContainerNews.setVisibility(View.GONE);
                }

            }
        });

        viewModel.liveDataIsLoading.observe(this, new Observer() {
            @Override
            public void onChanged(@Nullable Object o) {


                if (NewsActivity.this.isFinishing()) {
                    return;
                }
                if ((Boolean) o) {
                    appAlertLoaderDialog.start();
                } else {
                    appAlertLoaderDialog.stop();
                }
            }
        });

    }

    /**
     * Metohd of pull to refresh functionality
     */
    public void setPullToRefresh() {
        binding.swipeContainerNews.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                binding.swipeContainerNews.setRefreshing(false);
                viewModel.fetchNewsIdTest();
                binding.swipeContainerNews.setColorSchemeResources(android.R.color.holo_blue_bright,

                        android.R.color.holo_green_light,

                        android.R.color.holo_orange_light,

                        android.R.color.holo_red_light);
            }
        });
    }

    @Override
    public void onBackPressed() {
        showAppExitAlert();
    }

    /**
     * exit Alert
     */

    private void showAppExitAlert() {
        try {
            AlertDialog.Builder builder = new AlertDialog.Builder(NewsActivity.this);
            builder.setTitle(getString(R.string.app_name));
            builder.setMessage(getString(R.string.app_exit_msg));
            builder.setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                    NewsActivity.super.onBackPressed();
                    finish();

                }
            });
            builder.setNegativeButton(getString(R.string.cancel), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {

                }
            });

            AlertDialog dialog = builder.create();
            dialog.show();
        } catch (Exception e) {
            finish();
        }
    }
}
