package com.hacker.news.app.viewmodles;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;
import com.hacker.news.HackerApp;
import com.hacker.news.app.data.MVVMRepository;
import com.hacker.news.app.util.ProjectUtil;
import com.hacker.news.app.util.SharePreferenceUtil;
import io.reactivex.disposables.CompositeDisposable;

import javax.inject.Inject;


public class BaseViewModel<N> extends ViewModel {

    public MutableLiveData<Boolean> liveDataIsLoading = new MutableLiveData<>();

    public final CompositeDisposable disposable = new CompositeDisposable();

    @Inject
    public MVVMRepository repository;

    public int actionIndex = 0;

    @Inject
    public SharePreferenceUtil preferenceUtil;

    public ProjectUtil projectUtil = new ProjectUtil(HackerApp.getInstance(), preferenceUtil);

    @Override
    protected void onCleared() {
        super.onCleared();
        if (!disposable.isDisposed()) {
            disposable.dispose();
        }
    }

}