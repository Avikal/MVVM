package com.hacker.news.app.data.remote;

import com.hacker.news.app.data.model.NewsResponse;
import io.reactivex.Observable;
import retrofit2.http.*;

import java.util.List;

/**
 * Retrofit api calling
 */
public interface ApiInterface {

    /*Get the News id*/
    @GET("v0/topstories.json?print=pretty")
    Observable<List<Integer>> getNewsId();

    /*Fetch the news detail on behalf of the new id*/
    @GET("v0/item/{articleid}.json?print=pretty")
    Observable<NewsResponse> getNewsStories(@Path("articleid") int id);



}
