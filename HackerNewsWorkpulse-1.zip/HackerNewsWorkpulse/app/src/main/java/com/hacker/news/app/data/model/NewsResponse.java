package com.hacker.news.app.data.model;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/**
 * Model class and the name of the table
 */
@Entity(tableName = "news")
public class NewsResponse implements Serializable,Comparable {

    @PrimaryKey(autoGenerate = true)
    private Long appId;

    public Long getAppId() {
        return appId;
    }

    public void setAppId(Long appId) {
        this.appId = appId;
    }

    @ColumnInfo(name = "by")
    @SerializedName("by")
    private String by;

    @ColumnInfo(name = "descendants")
    @SerializedName("descendants")
    private Integer descendants;

    @ColumnInfo(name = "id")
    @SerializedName("id")
    private Integer id;

   /* @SerializedName("kids")
@ColumnInfo(name = "appId")
    private List<Integer> kids = null;*/

    @ColumnInfo(name = "score")
    @SerializedName("score")
    private Integer score;

    @ColumnInfo(name = "time")
    @SerializedName("time")
    private Integer time;

    @ColumnInfo(name = "title")
    @SerializedName("title")
    private String title;

    @ColumnInfo(name = "type")
    @SerializedName("type")
    private String type;

    @ColumnInfo(name = "url")
    @SerializedName("url")
    private String url;


    public String getBy() {
        return by;
    }

    public void setBy(String by) {
        this.by = by;
    }

    public Integer getDescendants() {
        return descendants;
    }

    public void setDescendants(Integer descendants) {
        this.descendants = descendants;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    /*   public List<Integer> getKids() {
           return kids;
       }

       public void setKids(List<Integer> kids) {
           this.kids = kids;
       }
   */
    public Integer getScore() {
        return score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }

    public Integer getTime() {
        return time;
    }

    public void setTime(Integer time) {
        this.time = time;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    @Override
    public int compareTo(@NonNull Object o) {
        int compareScore = ((NewsResponse) o).getScore();
        return compareScore - this.score;
    }
}
