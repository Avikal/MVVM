package com.hacker.news.app.view;

import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.os.Handler;
import com.hacker.news.HackerApp;
import com.hacker.news.app.R;
import com.hacker.news.app.databinding.ActivitySplashBinding;
import com.hacker.news.app.di.component.ActivityComponent;
import com.hacker.news.app.di.component.DaggerActivityComponent;
import com.hacker.news.app.di.module.CustActivityModule;
import com.hacker.news.app.util.SharePreferenceUtil;
import com.hacker.news.app.view.news.NewsActivity;

import javax.inject.Inject;

public class SplashActivity extends BaseActivity {

    private ActivitySplashBinding splashBinding;

    @Inject
    public SharePreferenceUtil sharePreferenceUtil;

    private ActivityComponent component;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        splashBinding = DataBindingUtil.setContentView(this,
                R.layout.activity_splash);
        component = DaggerActivityComponent.builder().custActivityModule(new CustActivityModule(this))
                .appComponent(((HackerApp) getApplication()).getAppComponent()).build();
        component.inject(this);
        HackerApp.getInstance().showLoadingAnimation(splashBinding.loadingImage);

        Handler handler = new Handler();

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                splashBinding.loadingImage.clearAnimation();
                startActivity(new Intent(SplashActivity.this, NewsActivity.class));
                finish();
            }
        }, 1000);
    }
}
