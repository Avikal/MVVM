package com.hacker.news.app.di.module;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import com.hacker.news.app.data.MVVMRepository;
import com.hacker.news.app.data.local.NewsDatabase;
import com.hacker.news.app.data.remote.ApiInterface;
import com.hacker.news.app.data.local.DaoAccess;
import com.hacker.news.app.util.SharePreferenceUtil;
import com.google.gson.Gson;
import dagger.Module;
import dagger.Provides;

import javax.inject.Singleton;

@Module
public class AppModule {

    public static final String PREFERENCE_NAME = "mvvmPrf";

    private Application mApplication;

    public AppModule(Application application) {
        mApplication = application;
    }

    @Provides
    @Singleton
    Application provideApplication() {
        return mApplication;
    }

    @Provides
    @Singleton
    Context provideContext() {
        return mApplication;
    }

    @Provides
    @Singleton
    SharedPreferences provideSharedPreference(Context context) {
        return context.getSharedPreferences(PREFERENCE_NAME, Context.MODE_PRIVATE);
    }

    @Provides
    @Singleton
    SharePreferenceUtil providePreference(SharedPreferences preferences, Gson gson) {
        return new SharePreferenceUtil(preferences, gson);
    }

    @Provides
    @Singleton
    public NewsDatabase providesRoomDatabase(Context context) {
        return NewsDatabase.getInstance(context);
    }

    @Provides
    @Singleton
    public DaoAccess providesDao(NewsDatabase database) {
        return database.getDao();
    }


    @Provides
    @Singleton
    MVVMRepository getRepository(ApiInterface apiCallInterface, SharePreferenceUtil sharePreferenceUtil,
                                 DaoAccess daoAccess) {
        return new MVVMRepository(apiCallInterface, sharePreferenceUtil,daoAccess);
    }
}
