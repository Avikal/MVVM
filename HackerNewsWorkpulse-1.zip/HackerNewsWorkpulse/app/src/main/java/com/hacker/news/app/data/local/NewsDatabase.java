package com.hacker.news.app.data.local;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;
import com.hacker.news.app.data.model.NewsResponse;

/**
 * DataBase class used for creating Local Db using RoomDatabase
 */
@Database(entities = {NewsResponse.class}, version = 1, exportSchema = false)
public abstract class NewsDatabase extends RoomDatabase {


    public abstract DaoAccess getDao();

    private static NewsDatabase instance;

    public static NewsDatabase getInstance(Context context) {

        synchronized (NewsDatabase.class) {
            if (instance == null) {
                instance = Room.databaseBuilder(context.getApplicationContext(),
                        NewsDatabase.class, "hacker_news")
                        .build();
            }
            return instance;
        }


    }
}
