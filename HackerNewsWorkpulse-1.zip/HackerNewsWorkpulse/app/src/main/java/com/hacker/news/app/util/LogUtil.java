package com.hacker.news.app.util;

import android.util.Log;
import com.hacker.news.app.BuildConfig;


/**
 * Custom Log util class
 */
public class LogUtil {

    public static void d(String TAG, String message) {
        if (BuildConfig.DEBUG) {
            Log.d(TAG, message);
        }
    }

    public static void e(String TAG, String message) {
        if (BuildConfig.DEBUG) {
            Log.e(TAG, message);
        }
    }

    public static void v(String TAG, String message) {
        if (BuildConfig.DEBUG) {
            Log.v(TAG, message);
        }
    }

    public static void w(String TAG, String message) {
        if (BuildConfig.DEBUG) {
            Log.w(TAG, message);
        }
    }
}
