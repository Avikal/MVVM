package com.cdn.mvvmarchitect.javabuild.data.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

public class ProductMainResponse implements Serializable {

    @SerializedName("missions")
    @Expose
    private List<Mission> missions = null;
    @SerializedName("missionsRange")
    @Expose
    private MissionsRange missionsRange;

    public List<Mission> getMissions() {
        return missions;
    }

    public void setMissions(List<Mission> missions) {
        this.missions = missions;
    }

    public MissionsRange getMissionsRange() {
        return missionsRange;
    }

    public void setMissionsRange(MissionsRange missionsRange) {
        this.missionsRange = missionsRange;
    }

    public class MissionsRange {

        @SerializedName("start")
        @Expose
        private String start;
        @SerializedName("end")
        @Expose
        private String end;

        public String getStart() {
            return start;
        }

        public void setStart(String start) {
            this.start = start;
        }

        public String getEnd() {
            return end;
        }

        public void setEnd(String end) {
            this.end = end;
        }
    }

    public class Project {

        @SerializedName("name")
        @Expose
        private String name;
        @SerializedName("id")
        @Expose
        private String id;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

    }

    public class Address {

        @SerializedName("id")
        @Expose
        private String id;
        @SerializedName("street")
        @Expose
        private String street;
        @SerializedName("city")
        @Expose
        private String city;
        @SerializedName("zipCode")
        @Expose
        private String zipCode;
        @SerializedName("district")
        @Expose
        private String district;
        @SerializedName("state")
        @Expose
        private String state;
        @SerializedName("addressAdditional")
        @Expose
        private String addressAdditional;
        @SerializedName("latitude")
        @Expose
        private String latitude;
        @SerializedName("longitude")
        @Expose
        private String longitude;
        @SerializedName("precision")
        @Expose
        private String precision;
        @SerializedName("namespace")
        @Expose
        private String namespace;
        @SerializedName("stateCode")
        @Expose
        private String stateCode;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getStreet() {
            return street;
        }

        public void setStreet(String street) {
            this.street = street;
        }

        public String getCity() {
            return city;
        }

        public void setCity(String city) {
            this.city = city;
        }

        public String getZipCode() {
            return zipCode;
        }

        public void setZipCode(String zipCode) {
            this.zipCode = zipCode;
        }

        public String getDistrict() {
            return district;
        }

        public void setDistrict(String district) {
            this.district = district;
        }

        public String getState() {
            return state;
        }

        public void setState(String state) {
            this.state = state;
        }

        public String getAddressAdditional() {
            return addressAdditional;
        }

        public void setAddressAdditional(String addressAdditional) {
            this.addressAdditional = addressAdditional;
        }

        public String getLatitude() {
            return latitude;
        }

        public void setLatitude(String latitude) {
            this.latitude = latitude;
        }

        public String getLongitude() {
            return longitude;
        }

        public void setLongitude(String longitude) {
            this.longitude = longitude;
        }

        public String getPrecision() {
            return precision;
        }

        public void setPrecision(String precision) {
            this.precision = precision;
        }

        public String getNamespace() {
            return namespace;
        }

        public void setNamespace(String namespace) {
            this.namespace = namespace;
        }

        public String getStateCode() {
            return stateCode;
        }

        public void setStateCode(String stateCode) {
            this.stateCode = stateCode;
        }

    }

    public class Client {

        @SerializedName("name")
        @Expose
        private String name;
        @SerializedName("shortName")
        @Expose
        private String shortName;
        @SerializedName("id")
        @Expose
        private String id;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getShortName() {
            return shortName;
        }

        public void setShortName(String shortName) {
            this.shortName = shortName;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

    }

    public class Color {

        @SerializedName("hexstring")
        @Expose
        private String hexstring;
        @SerializedName("rgb")
        @Expose
        private List<Integer> rgb = null;

        public String getHexstring() {
            return hexstring;
        }

        public void setHexstring(String hexstring) {
            this.hexstring = hexstring;
        }

        public List<Integer> getRgb() {
            return rgb;
        }

        public void setRgb(List<Integer> rgb) {
            this.rgb = rgb;
        }

    }

    public class Market {

        @SerializedName("id")
        @Expose
        private String id;
        @SerializedName("name")
        @Expose
        private String name;
        @SerializedName("address")
        @Expose
        private Address address;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public Address getAddress() {
            return address;
        }

        public void setAddress(Address address) {
            this.address = address;
        }

    }

    public class Mission {

        @SerializedName("id")
        @Expose
        private String id;
        @SerializedName("client")
        @Expose
        private Client client;
        @SerializedName("project")
        @Expose
        private Project project;
        @SerializedName("tasks")
        @Expose
        private List<Task> tasks = null;
        @SerializedName("market")
        @Expose
        private Market market;
        @SerializedName("start")
        @Expose
        private String start;
        @SerializedName("end")
        @Expose
        private String end;
        @SerializedName("type")
        @Expose
        private String type;
        @SerializedName("assignmentId")
        @Expose
        private String assignmentId;
        @SerializedName("updated")
        @Expose
        private String updated;
        @SerializedName("assignmentStatus")
        @Expose
        private Integer assignmentStatus;
        @SerializedName("commissionId")
        @Expose
        private String commissionId;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public Client getClient() {
            return client;
        }

        public void setClient(Client client) {
            this.client = client;
        }

        public Project getProject() {
            return project;
        }

        public void setProject(Project project) {
            this.project = project;
        }

        public List<Task> getTasks() {
            return tasks;
        }

        public void setTasks(List<Task> tasks) {
            this.tasks = tasks;
        }

        public Market getMarket() {
            return market;
        }

        public void setMarket(Market market) {
            this.market = market;
        }

        public String getStart() {
            return start;
        }

        public void setStart(String start) {
            this.start = start;
        }

        public String getEnd() {
            return end;
        }

        public void setEnd(String end) {
            this.end = end;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getAssignmentId() {
            return assignmentId;
        }

        public void setAssignmentId(String assignmentId) {
            this.assignmentId = assignmentId;
        }

        public String getUpdated() {
            return updated;
        }

        public void setUpdated(String updated) {
            this.updated = updated;
        }

        public Integer getAssignmentStatus() {
            return assignmentStatus;
        }

        public void setAssignmentStatus(Integer assignmentStatus) {
            this.assignmentStatus = assignmentStatus;
        }

        public String getCommissionId() {
            return commissionId;
        }

        public void setCommissionId(String commissionId) {
            this.commissionId = commissionId;
        }

    }

    public class Status {

        @SerializedName("value")
        @Expose
        private String value;
        @SerializedName("color")
        @Expose
        private Color color;

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }

        public Color getColor() {
            return color;
        }

        public void setColor(Color color) {
            this.color = color;
        }

    }

    public class Task {

        @SerializedName("id")
        @Expose
        private String id;
        @SerializedName("type")
        @Expose
        private String type;
        @SerializedName("name")
        @Expose
        private String name;
        @SerializedName("description")
        @Expose
        private String description;
        @SerializedName("referenceId")
        @Expose
        private Object referenceId;
        @SerializedName("requestTime")
        @Expose
        private Object requestTime;
        @SerializedName("requestGeoData")
        @Expose
        private Object requestGeoData;
        @SerializedName("updated")
        @Expose
        private String updated;
        @SerializedName("isExecutable")
        @Expose
        private Integer isExecutable;
        @SerializedName("status")
        @Expose
        private Status status;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public Object getReferenceId() {
            return referenceId;
        }

        public void setReferenceId(Object referenceId) {
            this.referenceId = referenceId;
        }

        public Object getRequestTime() {
            return requestTime;
        }

        public void setRequestTime(Object requestTime) {
            this.requestTime = requestTime;
        }

        public Object getRequestGeoData() {
            return requestGeoData;
        }

        public void setRequestGeoData(Object requestGeoData) {
            this.requestGeoData = requestGeoData;
        }

        public String getUpdated() {
            return updated;
        }

        public void setUpdated(String updated) {
            this.updated = updated;
        }

        public Integer getIsExecutable() {
            return isExecutable;
        }

        public void setIsExecutable(Integer isExecutable) {
            this.isExecutable = isExecutable;
        }

        public Status getStatus() {
            return status;
        }

        public void setStatus(Status status) {
            this.status = status;
        }

    }

}
