package com.cdn.mvvmarchitect.javabuild.view.activity;

import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.os.Handler;
import com.cdn.mvvmarchitect.MVVMApp;
import com.cdn.mvvmarchitect.R;
import com.cdn.mvvmarchitect.databinding.ActivitySplashBinding;
import com.cdn.mvvmarchitect.javabuild.di.component.ActivityComponent;
import com.cdn.mvvmarchitect.javabuild.di.component.DaggerActivityComponent;
import com.cdn.mvvmarchitect.javabuild.di.module.CustActivityModule;
import com.cdn.mvvmarchitect.javabuild.util.SharePreferenceUtil;
import com.cdn.mvvmarchitect.javabuild.view.login.LoginActivity;
import com.cdn.mvvmarchitect.javabuild.view.news.NewsActivity;
import com.cdn.mvvmarchitect.javabuild.view.profile.ProfileListActivity;

import javax.inject.Inject;

public class SplashActivity extends BaseActivity {

    private ActivitySplashBinding splashBinding;

    @Inject
    public SharePreferenceUtil sharePreferenceUtil;

    private ActivityComponent component;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        splashBinding = DataBindingUtil.setContentView(this,
                R.layout.activity_splash);
        component = DaggerActivityComponent.builder().custActivityModule(new CustActivityModule(this))
                .appComponent(((MVVMApp) getApplication()).getAppComponent()).build();
        component.inject(this);
        MVVMApp.getInstance().showLoadingAnimation(splashBinding.loadingImage);

        Handler handler = new Handler();

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                splashBinding.loadingImage.clearAnimation();
                startActivity(new Intent(SplashActivity.this, NewsActivity.class));
                finish();
               /* if (sharePreferenceUtil.isLoginExist) {
                    startActivity(new Intent(SplashActivity.this, ProfileListActivity.class));
                    finish();
                } else {
                    startActivity(new Intent(SplashActivity.this, LoginActivity.class));
                    finish();
                }*/
            }
        }, 1000);
    }
}
