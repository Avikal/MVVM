package com.cdn.mvvmarchitect;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.support.multidex.MultiDex;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import com.cdn.mvvmarchitect.javabuild.di.component.AppComponent;
import com.cdn.mvvmarchitect.javabuild.di.component.DaggerAppComponent;
import com.cdn.mvvmarchitect.javabuild.di.module.AppModule;
import com.cdn.mvvmarchitect.javabuild.di.module.NetModule;
import com.cdn.mvvmarchitect.javabuild.util.SharePreferenceUtil;
import com.cdn.mvvmarchitect.javabuild.view.login.LoginActivity;

import javax.inject.Inject;

public class MVVMApp extends Application {

    private static MVVMApp instance;

    public static MVVMApp getInstance() {
        return instance;
    }

    private static synchronized void setInstance(MVVMApp app) {
        instance = app;
    }

    private AppComponent appComponent;

    @Inject
    public SharePreferenceUtil sharePreferenceUtil;

    @Override
    public void onCreate() {
        super.onCreate();
        setInstance(this);
        appComponent = DaggerAppComponent.builder()
                .appModule(new AppModule(this))
                .netModule(new NetModule("https://hacker-news.firebaseio.com/"))
                .build();
        appComponent.inject(this);
        sharePreferenceUtil.loadValues();
    }


    public AppComponent getAppComponent() {
        return appComponent;
    }


    /**
     * This method makes rotating loader animation on loading icon.
     */
    public void showLoadingAnimation(ImageView loadingImage) {
        RotateAnimation rotateAnimation = new RotateAnimation(0, 180,
                Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        rotateAnimation.setRepeatCount(Animation.INFINITE);
        rotateAnimation.setDuration(1000);
        loadingImage.setAnimation(rotateAnimation);
    }

    @Override
    protected void attachBaseContext(Context context) {
        super.attachBaseContext(context);
        MultiDex.install(context);
    }

    public void logout() {
        Intent intent = new Intent(this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);

    }
}
