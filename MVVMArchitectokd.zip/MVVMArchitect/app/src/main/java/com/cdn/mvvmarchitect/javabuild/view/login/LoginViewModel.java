package com.cdn.mvvmarchitect.javabuild.view.login;

import android.arch.lifecycle.MutableLiveData;
import android.util.Patterns;
import com.cdn.mvvmarchitect.MVVMApp;
import com.cdn.mvvmarchitect.R;
import com.cdn.mvvmarchitect.javabuild.data.MVVMRepository;
import com.cdn.mvvmarchitect.javabuild.data.model.ResponseUserDetail;
import com.cdn.mvvmarchitect.javabuild.data.model.request.LoginRequest;
import com.cdn.mvvmarchitect.javabuild.util.AppConstant;
import com.cdn.mvvmarchitect.javabuild.util.ConnectionLiveData;
import com.cdn.mvvmarchitect.javabuild.util.LogUtil;
import com.cdn.mvvmarchitect.javabuild.util.MD5Util;
import com.cdn.mvvmarchitect.javabuild.viewmodles.BaseViewModel;
import com.google.gson.JsonObject;
import com.test.contactapp.di.scope.ActivityScope;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import kotlin.TypeCastException;
import okhttp3.ResponseBody;
import retrofit2.HttpException;

import javax.inject.Inject;

@ActivityScope
public class LoginViewModel extends BaseViewModel {

    public static final String TAG = LoginViewModel.class.getSimpleName();

    @Inject
    public ConnectionLiveData connection;


    public MutableLiveData<Boolean> responseStatusLiveData = new MutableLiveData<>();

    public MutableLiveData<String> email = new MutableLiveData<>();
    public MutableLiveData<String> password = new MutableLiveData<>();


    @Inject
    public LoginViewModel(MVVMRepository repository) {
        this.repository = repository;
    }

    public void onLoginClicked() {
        LogUtil.e(TAG, "Login Clicked");
        if (validate()) {
            login();
        }
    }

    public void login() {
        LoginRequest loginRequest = new LoginRequest();
        liveDataIsLoading.setValue(true);
        loginRequest.setUsername(email.getValue());
        loginRequest.setPassword(MD5Util.md5(password.getValue()));
        loginRequest.setClient_id(AppConstant.PARAM_CLIENT_ID_VALUE);
        loginRequest.setClient_secret(AppConstant.PARAM_CLIENT_SECRETE_VALUE);
        loginRequest.setGrant_type(AppConstant.PARAM_GRANT_TYPE_VALUE);
        LogUtil.e(TAG, "userName " + email.getValue() + " password " + password.getValue());
        if (projectUtil.checkNetwork()) {

            disposable.add(repository.login(loginRequest)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(new Consumer<JsonObject>() {
                        @Override
                        public void accept(JsonObject jsonObject) throws Exception {
                            preferenceUtil.setAccessToken(jsonObject.get("access_token").getAsString());
                            preferenceUtil.setRefreshToken(jsonObject.get("refresh_token").getAsString());
                            LogUtil.e(TAG, "ACCESS_TOKEN " + preferenceUtil.getAccessToken());
                            String tempString = " Bearer " + jsonObject.get("access_token").getAsString();
                            disposable.add(repository.fetchUserData(tempString)
                                    .subscribeOn(Schedulers.io())
                                    .observeOn(AndroidSchedulers.mainThread())
                                    .subscribe(new Consumer<ResponseUserDetail>() {
                                        @Override
                                        public void accept(ResponseUserDetail responseUserDetail) throws Exception {
                                            preferenceUtil.setLoggedIn(true);
                                            preferenceUtil.setLoggedUser(responseUserDetail.getUser());
                                            liveDataIsLoading.setValue(false);
                                            responseStatusLiveData.setValue(true);
                                        }
                                    }, new Consumer<Throwable>() {
                                        @Override
                                        public void accept(Throwable throwable) throws Exception {
                                            liveDataIsLoading.setValue(false);
                                            responseStatusLiveData.setValue(false);
                                        }
                                    }));

                        }
                    }, new Consumer<Throwable>() {
                        @Override
                        public void accept(Throwable throwable) throws Exception {
                            liveDataIsLoading.setValue(false);
                            responseStatusLiveData.setValue(false);
                            if (throwable instanceof HttpException) {
                                if (throwable == null) {
                                    throw new TypeCastException("null cannot be cast to non-null type com.jakewharton.retrofit2.adapter.rxjava2.HttpException");
                                }

                                HttpException e = (HttpException) throwable;
                                int code = e.response().code();
                                if (code == 401) {
                                    projectUtil.showToast(projectUtil.appContext.getString(R.string.status_401));
                                }
                            }
                            {
                                projectUtil.showToast(projectUtil.appContext.getString(R.string.general_error_message));
                            }

                        }
                    }));
        } else {
            liveDataIsLoading.setValue(false);
            projectUtil.showToast(projectUtil.getApiErrorMsg(R.string.internet_unavailable));
        }
    }

    public boolean validate() {
        if (email.getValue() == null) {
            projectUtil.showToast(R.string.login_valid_email);
            return false;
        } else if (email.getValue().isEmpty()) {
            projectUtil.showToast(R.string.login_valid_email);
            return false;
        } else if (!validEmail(email.getValue())) {
            projectUtil.showToast(R.string.login_valid_email);
            return false;
        } else if (password.getValue() == null) {
            projectUtil.showToast(R.string.login_valid_password);
            return false;
        } else if (password.getValue().isEmpty()) {
            projectUtil.showToast(R.string.login_valid_password);
            return false;
        }
        return true;
    }

    public boolean validEmail(String emailID) {
        return Patterns.EMAIL_ADDRESS.matcher(emailID).matches();
    }

}
