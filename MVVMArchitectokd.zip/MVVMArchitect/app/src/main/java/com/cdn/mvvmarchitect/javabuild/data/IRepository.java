package com.cdn.mvvmarchitect.javabuild.data;

import com.cdn.mvvmarchitect.javabuild.data.model.NewsResponse;
import com.cdn.mvvmarchitect.javabuild.data.model.ProductMainResponse;
import com.cdn.mvvmarchitect.javabuild.data.model.ResponseUserDetail;
import com.cdn.mvvmarchitect.javabuild.data.model.request.LoginRequest;
import com.google.gson.JsonObject;
import io.reactivex.Observable;
import kotlin.jvm.internal.markers.KMutableList;

import java.util.List;
import java.util.Map;

interface IRepository {

    Observable<ProductMainResponse> getProductList(String start, String end, String sort);

    Observable<JsonObject> login(LoginRequest loginRequest);

    Observable<ResponseUserDetail> fetchUserData(String header);

    Observable<JsonObject> getRefreshToken(LoginRequest loginRequest);

    Observable<List<Integer>> getNewsId();

    Observable<NewsResponse> getNewsStory(int id);

}
