package com.cdn.mvvmarchitect.javabuild.di.component;

import android.content.Context;
import com.cdn.mvvmarchitect.MVVMApp;
import com.cdn.mvvmarchitect.javabuild.data.MVVMRepository;
import com.cdn.mvvmarchitect.javabuild.data.remote.ApiInterface;
import com.cdn.mvvmarchitect.javabuild.di.module.AppModule;
import com.cdn.mvvmarchitect.javabuild.di.module.NetModule;
import com.cdn.mvvmarchitect.javabuild.util.SharePreferenceUtil;

import dagger.Component;

import javax.inject.Singleton;

@Component(modules = {AppModule.class,
        NetModule.class
})
@Singleton
public interface AppComponent {

    public MVVMRepository repository();

    SharePreferenceUtil sharePrefUtil();
    Context context();


    void inject(MVVMApp mvvmApp);

    void inject(ApiInterface apiInterface);

}


