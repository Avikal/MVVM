package com.cdn.mvvmarchitect.javabuild.view.profile;


import com.cdn.mvvmarchitect.javabuild.data.model.ProductMainResponse;

public interface OnMissionItemClick {
    void onClick(ProductMainResponse.Mission mission);
}