package com.cdn.mvvmarchitect.javabuild.di.module;

import android.content.Context;
import android.os.Build;
import com.cdn.mvvmarchitect.BuildConfig;
import com.cdn.mvvmarchitect.javabuild.data.MVVMRepository;
import com.cdn.mvvmarchitect.javabuild.data.remote.ApiInterface;
import com.cdn.mvvmarchitect.javabuild.util.SharePreferenceUtil;
import com.google.gson.Gson;
import dagger.Module;
import dagger.Provides;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

import javax.inject.Singleton;
import java.util.concurrent.TimeUnit;


@Module
public class NetModule {

    private String baseUrl;

    public NetModule(String baseUrl) {
        this.baseUrl = baseUrl;
    }


    @Provides
    @Singleton
    OkHttpClient privateOkHttpClient(Context context) {
        OkHttpClient.Builder okHBuilder = new OkHttpClient.Builder();

        okHBuilder.connectTimeout(2, TimeUnit.MINUTES);
        okHBuilder.readTimeout(2, TimeUnit.MINUTES);
        okHBuilder.writeTimeout(2, TimeUnit.MINUTES);

        if (BuildConfig.DEBUG) {
            HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
            interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
            okHBuilder.addInterceptor(interceptor);
        }

        OkHttpClient client = okHBuilder.build();
        return client;
    }

    @Provides
    @Singleton
    Gson provideGson() {
        return new Gson();
    }

    @Provides
    @Singleton
    Retrofit provideRetrofit(OkHttpClient client, Gson gson) {
        return new Retrofit.Builder()
                .baseUrl(baseUrl)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .client(client)
                .build();
    }

    @Provides
    @Singleton
    ApiInterface provideAPI(Retrofit retrofit) {
        return retrofit.create(ApiInterface.class);
    }

}
