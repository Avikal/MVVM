package com.cdn.mvvmarchitect.javabuild.view.profile;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import com.cdn.mvvmarchitect.MVVMApp;
import com.cdn.mvvmarchitect.R;
import com.cdn.mvvmarchitect.databinding.ActivityProfileListBinding;
import com.cdn.mvvmarchitect.javabuild.data.model.ProductMainResponse;
import com.cdn.mvvmarchitect.javabuild.di.component.ActivityComponent;

import com.cdn.mvvmarchitect.javabuild.di.component.DaggerActivityComponent;
import com.cdn.mvvmarchitect.javabuild.di.module.CustActivityModule;
import com.cdn.mvvmarchitect.javabuild.view.activity.BaseActivity;
import com.cdn.mvvmarchitect.javabuild.view.adapter.section.MissionSection;
import com.cdn.mvvmarchitect.javabuild.view.adapter.section.SectionedRecyclerViewAdapter;
import com.cdn.mvvmarchitect.javabuild.viewmodles.ViewModelFactory;

import javax.inject.Inject;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class ProfileListActivity extends BaseActivity {

    private ActivityProfileListBinding profileListBinding;

    @Inject
    ViewModelFactory<ProfileListViewModel> mFactory;

    public ProfileListViewModel viewModel;

    ActivityComponent component;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        profileListBinding = DataBindingUtil.setContentView(this,
                R.layout.activity_profile_list);
        component = DaggerActivityComponent.builder().custActivityModule(new CustActivityModule(this))
                .appComponent(((MVVMApp) getApplication()).getAppComponent()).build();
        component.inject(this);

        viewModel = ViewModelProviders.of(this, mFactory).get(ProfileListViewModel.class);
        profileListBinding.recycleView.setLayoutManager(new LinearLayoutManager(this));

        viewModel.fetchNewId();

        viewModel.responseLiveData.observe(this, new Observer<ProductMainResponse>() {
            @Override
            public void onChanged(@Nullable ProductMainResponse productMainResponse) {
                List<ProductMainResponse.Mission> as = productMainResponse.getMissions();
//                setSectionList(as);
            }
        });
    }

    public void setSectionList(Map<String, List<ProductMainResponse.Mission>> map) {
        SectionedRecyclerViewAdapter adapter = new SectionedRecyclerViewAdapter();

        if (map != null) {
            Iterator iterator = map.entrySet().iterator();
            while (iterator.hasNext()) {
                Entry entry = (Entry) iterator.next();
                String key = (String) entry.getKey();
                List value = (List) entry.getValue();
                MissionSection missionSection = new MissionSection(ProfileListActivity.this,
                        key, value, (OnMissionItemClick) ProfileListActivity.this);
                adapter.addSection(missionSection);
            }
            profileListBinding.recycleView.setAdapter(adapter);

        }
    }
}


