package com.cdn.mvvmarchitect.javabuild.view.news;

import android.arch.lifecycle.MutableLiveData;
import android.util.Log;
import com.cdn.mvvmarchitect.javabuild.data.MVVMRepository;
import com.cdn.mvvmarchitect.javabuild.data.model.NewsResponse;
import com.cdn.mvvmarchitect.javabuild.data.remote.ApiInterface;
import com.cdn.mvvmarchitect.javabuild.util.LogUtil;
import com.cdn.mvvmarchitect.javabuild.viewmodles.BaseViewModel;
import io.reactivex.Observable;
import io.reactivex.ObservableSource;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Action;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;
import io.reactivex.schedulers.Schedulers;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class NewsViewModel extends BaseViewModel {

    public MVVMRepository repository;

    @Inject
    public NewsViewModel(MVVMRepository repository) {
        this.repository = repository;
    }

    public final MutableLiveData<List<Integer>> newsIdData = new MutableLiveData<>();

    public MutableLiveData<ArrayList<NewsResponse>> newsData = new MutableLiveData<>();

    public ArrayList<NewsResponse> newsList = new ArrayList<>();

    public ArrayList<Integer> commonIds = new ArrayList<>();

    public int count = 5;

    public void fetchNewsIdTest() {
        liveDataIsLoading.setValue(true);
        disposable.add(repository.getNewsId()
                .flatMap(new Function<List<Integer>, ObservableSource<Integer>>() {
                    @Override
                    public ObservableSource<Integer> apply(List<Integer> tickets) throws Exception {
                        LogUtil.e("NewSId ", " " + tickets.size());
                        count = count + commonIds.size();
                        for (int i = commonIds.size(); i < count; i++) {
                            commonIds.add(tickets.get(i));
                        }

                        return Observable.fromIterable(commonIds);
                    }
                }).flatMap(new Function<Integer, ObservableSource<NewsResponse>>() {
                    @Override
                    public ObservableSource<NewsResponse> apply(Integer integer) throws Exception {
                        return repository.getNewsStory(integer);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<NewsResponse>() {
                    @Override
                    public void accept(NewsResponse newsResponse) throws Exception {
                        newsList.add(newsResponse);

                    }


                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {

                    }
                }, new Action() {
                    @Override
                    public void run() throws Exception {
                        LogUtil.e("NewSId ", " " + newsList.size());
                        Collections.sort(newsList);
                        newsData.setValue(newsList);
                        liveDataIsLoading.setValue(false);
                    }
                }));

    }

    public void fetchNewsId() {
        liveDataIsLoading.setValue(true);
        disposable.add(repository.getNewsId()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<List<Integer>>() {
                               @Override
                               public void accept(List<Integer> integers) throws Exception {
                                   newsIdData.setValue(integers);
                                   for (int i = 0; i < count; i++) {
                                       LogUtil.e("NewSId ", " " + integers.get(i));
                                       getNewsData(integers.get(i));
                                   }

                               }
                           },
                        new Consumer<Throwable>() {
                            @Override
                            public void accept(Throwable throwable) throws Exception {
                                liveDataIsLoading.setValue(false);
                            }
                        }, new Action() {
                            @Override
                            public void run() throws Exception {
                                LogUtil.e("NewSId ", " " + newsList.size());
                                newsData.setValue(newsList);
                                liveDataIsLoading.setValue(false);
                            }
                        }));
    }

    public void getNewsData(Integer id) {
        disposable.add(repository.getNewsStory(id)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<NewsResponse>() {
                               @Override
                               public void accept(NewsResponse newsResponse) throws Exception {
                                   LogUtil.e("Title ", newsResponse.getTitle());
                                   newsList.add(newsResponse);
                               }
                           },
                        new Consumer<Throwable>() {
                            @Override
                            public void accept(Throwable throwable) throws Exception {
                                liveDataIsLoading.setValue(false);
                            }
                        }));
    }

    public void saveNewsInDB(MutableLiveData<ArrayList<NewsResponse>> newsDataList) {

    }


}
