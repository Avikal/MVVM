package com.cdn.mvvmarchitect.javabuild.viewmodles;

import android.arch.lifecycle.ViewModel;
import android.arch.lifecycle.ViewModelProvider;
import com.test.contactapp.di.scope.ActivityScope;

import javax.inject.Inject;


@ActivityScope
public class ViewModelFactory<V extends ViewModel> implements ViewModelProvider.Factory {

    private static final String TAG = ViewModelFactory.class.getSimpleName();
    private V viewModel;

    @Inject
    public ViewModelFactory(V viewModel) {
        this.viewModel = viewModel;
    }

    @Override
    public <T extends ViewModel> T create(Class<T> modelClass) {
        if (modelClass.isAssignableFrom(viewModel.getClass())) {
            return (T) viewModel;
        }
        throw new IllegalArgumentException("Unknown class: " + modelClass);
    }
}
