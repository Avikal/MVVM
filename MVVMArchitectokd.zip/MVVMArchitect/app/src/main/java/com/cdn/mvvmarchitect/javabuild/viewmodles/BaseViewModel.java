package com.cdn.mvvmarchitect.javabuild.viewmodles;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;
import com.cdn.mvvmarchitect.MVVMApp;
import com.cdn.mvvmarchitect.R;
import com.cdn.mvvmarchitect.javabuild.data.MVVMRepository;
import com.cdn.mvvmarchitect.javabuild.data.model.request.LoginRequest;
import com.cdn.mvvmarchitect.javabuild.util.AppConstant;
import com.cdn.mvvmarchitect.javabuild.util.ProjectUtil;
import com.cdn.mvvmarchitect.javabuild.util.SharePreferenceUtil;
import com.google.gson.JsonObject;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import kotlin.TypeCastException;
import okhttp3.ResponseBody;
import org.json.JSONObject;
import retrofit2.HttpException;

import javax.inject.Inject;


public class BaseViewModel<N> extends ViewModel {

    public MutableLiveData<Boolean> liveDataIsLoading = new MutableLiveData<>();

    public final CompositeDisposable disposable = new CompositeDisposable();

    @Inject
    public MVVMRepository repository;

    public int actionIndex = 0;

    @Inject
    public SharePreferenceUtil preferenceUtil;

    public ProjectUtil projectUtil = new ProjectUtil(MVVMApp.getInstance(),preferenceUtil);

    @Override
    protected void onCleared() {
        super.onCleared();
        if (!disposable.isDisposed()) {
            disposable.dispose();
        }
    }

    public void doCheckError(Throwable error, Boolean requireActionBlock, int actionIndex) {
        this.actionIndex = actionIndex;
        if (error instanceof HttpException) {
            try {
                HttpException e = (HttpException) error;
                int code = e.response().code();
                if (code != 401) {
                    ResponseBody responseBody = e.response().errorBody();
                    String errorBody = responseBody != null ? responseBody.toString() : null;
                    JSONObject errorObj = new JSONObject(errorBody);
                    projectUtil.getApiMessage(errorObj);
                    return;
                }
                callRefreshToken();

            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }

    public void callRefreshToken() {
        LoginRequest loginRequest = new LoginRequest();
        String refresh_token = preferenceUtil.refresh_token;
        loginRequest.setGrant_type("refresh_token");
        loginRequest.setClient_id(AppConstant.PARAM_CLIENT_ID_VALUE);
        loginRequest.setClient_secret(AppConstant.PARAM_CLIENT_SECRETE_VALUE);
        loginRequest.setRefresh_token(refresh_token);

        disposable.add(repository.getRefreshToken(loginRequest)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<JsonObject>() {
                    @Override
                    public void accept(JsonObject jsonObject) throws Exception {
                        preferenceUtil.setAccessToken(jsonObject.get("access_token").getAsString());
                        preferenceUtil.setRefreshToken(jsonObject.get("refresh_token").getAsString());
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        if (throwable instanceof HttpException) {
                            if (throwable == null) {
                                throw new TypeCastException("null cannot be cast to non-null type com.jakewharton.retrofit2.adapter.rxjava2.HttpException");
                            }

                            HttpException e = (HttpException) throwable;
                            int code = e.response().code();
                            ResponseBody responseBody = e.response().errorBody();
                            String errorBody = responseBody != null ? responseBody.toString() : null;
                            JSONObject errorObj = new JSONObject(errorBody);
                            if (code != 400) {
                                projectUtil.getApiMessage(errorObj);
                                projectUtil.showToast(errorObj.getString("detail"));
                                projectUtil.logout();
                            }
                        }
                        {
                            projectUtil.showToast(projectUtil.appContext.getString(R.string.general_error_message));
                        }
                    }
                }));


    }

}