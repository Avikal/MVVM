package com.cdn.mvvmarchitect.javabuild.data.remote;

import com.cdn.mvvmarchitect.javabuild.data.model.Coin;
import com.cdn.mvvmarchitect.javabuild.data.model.NewsResponse;
import com.cdn.mvvmarchitect.javabuild.data.model.ProductMainResponse;
import com.cdn.mvvmarchitect.javabuild.data.model.ResponseUserDetail;
import com.cdn.mvvmarchitect.javabuild.data.model.request.LoginRequest;
import com.cdn.mvvmarchitect.javabuild.util.AppConstant;
import com.google.gson.JsonObject;
import io.reactivex.Observable;
import retrofit2.http.*;

import java.util.List;
import java.util.Map;


public interface ApiInterface {

    public static String CONTENT_TYPE_XML = "Content-Type: text/xml";
    public static String CONTENT_TYPE_JSON = "Content-Type: application/json";
    public static String ACCEPT_CHARSET = "Accept-Charset: utf-8";
    public static String ACCEPT = "Accept:application/json";
    public static String BASE_URL_1 = "https://api.profiflitzer.de:8080";

    @GET(AppConstant.MISSION_USER)
    @Headers({CONTENT_TYPE_JSON, ACCEPT_CHARSET, ACCEPT})
    Observable<ProductMainResponse> getFrontPageCoinData(@Header("Authorization") String auth,
                                                         @Query("start") String start,
                                                         @Query("end") String end,
                                                         @Query("sort") String sort);

    @POST(AppConstant.LOGIN_OAUTH)
    Observable<JsonObject> getLoginData(@Body LoginRequest loginRequest);

    @GET(AppConstant.USER_INFO)
    @Headers({CONTENT_TYPE_JSON, CONTENT_TYPE_XML, ACCEPT_CHARSET, ACCEPT})
    Observable<ResponseUserDetail> fetchUserData(@Header("Authorization") String s);

    @POST(AppConstant.LOGIN_OAUTH)
    @Headers({CONTENT_TYPE_JSON, CONTENT_TYPE_XML, ACCEPT_CHARSET, ACCEPT})
    Observable<JsonObject> getRefreshToken(@Header("Authorization") String s, @Body LoginRequest loginRequest);

    @GET("v0/topstories.json?print=pretty")
    Observable<List<Integer>> getNewsId();

    @GET("v0/item/{articleid}.json?print=pretty")
    Observable<NewsResponse> getNewsStories(@Path("articleid") int id);

}
