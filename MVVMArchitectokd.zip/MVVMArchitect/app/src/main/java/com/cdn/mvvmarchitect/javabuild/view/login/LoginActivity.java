package com.cdn.mvvmarchitect.javabuild.view.login;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Toast;
import com.cdn.mvvmarchitect.MVVMApp;
import com.cdn.mvvmarchitect.R;
import com.cdn.mvvmarchitect.databinding.ActivityLoginBinding;
import com.cdn.mvvmarchitect.javabuild.di.component.ActivityComponent;
import com.cdn.mvvmarchitect.javabuild.di.component.DaggerActivityComponent;
import com.cdn.mvvmarchitect.javabuild.di.module.CustActivityModule;
import com.cdn.mvvmarchitect.javabuild.util.AppAlertLoaderDialog;
import com.cdn.mvvmarchitect.javabuild.util.ConnectionModel;
import com.cdn.mvvmarchitect.javabuild.view.activity.BaseActivity;
import com.cdn.mvvmarchitect.javabuild.view.profile.ProfileListActivity;
import com.cdn.mvvmarchitect.javabuild.viewmodles.ViewModelFactory;

import javax.inject.Inject;

public class LoginActivity extends BaseActivity {

    private ActivityLoginBinding loginBinding;

    @Inject
    public AppAlertLoaderDialog appAlertLoaderDialog;

    @Inject
    public ViewModelFactory<LoginViewModel> factory;

    public LoginViewModel viewModel;

    private ActivityComponent component;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loginBinding = DataBindingUtil.setContentView(this,
                R.layout.activity_login);
        component = DaggerActivityComponent.builder().custActivityModule(new CustActivityModule(this))
                .appComponent(((MVVMApp) getApplication()).getAppComponent()).build();
        component.inject(this);

        viewModel = ViewModelProviders.of(this, factory).get(LoginViewModel.class);

        loginBinding.setLifecycleOwner(this);
        loginBinding.setLoginViewModel(viewModel);
        setObserver();
    }

    public void setObserver() {

        viewModel.responseStatusLiveData.observe(this, new Observer<Boolean>() {
            @Override
            public void onChanged(@Nullable Boolean isLoggedIn) {
                if (isLoggedIn) {
                    Intent intent = new Intent(LoginActivity.this, ProfileListActivity.class);
                    startActivity(intent);
                    finish();
                    Toast.makeText(LoginActivity.this, "Login Success", Toast.LENGTH_SHORT).show();
                }

            }
        });

        viewModel.liveDataIsLoading.observe(this, new Observer() {
            @Override
            public void onChanged(@Nullable Object o) {
                if (LoginActivity.this.isFinishing()) {
                    return;
                }
                if ((Boolean) o) {
                    appAlertLoaderDialog.start();
                } else {
                    appAlertLoaderDialog.stop();
                }
            }
        });

        viewModel.connection.observe(this, new Observer<ConnectionModel>() {
            @Override
            public void onChanged(@Nullable ConnectionModel connectionModel) {
                if (connectionModel.isConnected()) {
                    loginBinding.networkErrorLayout.setVisibility(View.GONE);
                } else {
                    loginBinding.networkErrorLayout.setVisibility(View.VISIBLE);
                }
            }
        });
    }
}
