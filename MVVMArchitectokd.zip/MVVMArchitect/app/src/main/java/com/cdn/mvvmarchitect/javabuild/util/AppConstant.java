package com.cdn.mvvmarchitect.javabuild.util;

public class AppConstant {

    public static final String FETCH_JSON = "json";
    public static final String LOGIN_OAUTH = "oauth";
    public static final String USER_INFO = "userInformations";
    public static final String MISSION_USER = "missionsForUser";

    public static final String PARAM_CLIENT_SECRETE_VALUE = "4$=gwe6wzz2H^-Jgu6*wBqeVD&@v2FSkSs_VMQmQGR+*RT+LRh_c6&$GABJGZBYw";
    public static final String PARAM_CLIENT_ID_VALUE = "mobileapp";
    public static final String PARAM_GRANT_TYPE_VALUE = "password";

}
