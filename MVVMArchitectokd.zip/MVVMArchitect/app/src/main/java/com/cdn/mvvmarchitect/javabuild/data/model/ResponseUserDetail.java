package com.cdn.mvvmarchitect.javabuild.data.model;

public class ResponseUserDetail {

    private User user;

    public ResponseUserDetail(User user) {
        this.user = user;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
