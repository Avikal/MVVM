package com.workpulse.hackernewsapp.data;

import com.workpulse.hackernewsapp.data.source.remote.ApiInterface;
import com.workpulse.hackernewsapp.data.source.remote.model.NewsResponse;
import com.workpulse.hackernewsapp.domin.repository.IRepository;

import java.util.List;

import io.reactivex.Observable;


public class Repository implements IRepository {

    public ApiInterface apiInterface;

    public Repository(ApiInterface apiInterface) {
        this.apiInterface = apiInterface;
    }

    @Override
    public Observable<List<Integer>> getStories() {
        return apiInterface.getTopStories();
    }

    @Override
    public Observable<NewsResponse> getHackerNews(int id) {
        return apiInterface.getNewsStories(id);
    }
}
