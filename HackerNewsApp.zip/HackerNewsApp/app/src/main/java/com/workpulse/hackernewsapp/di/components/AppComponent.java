package com.workpulse.hackernewsapp.di.components;

import android.content.Context;

import com.workpulse.hackernewsapp.HackerApp;
import com.workpulse.hackernewsapp.di.module.AppModule;
import com.workpulse.hackernewsapp.di.module.NetModule;
import com.workpulse.hackernewsapp.domin.repository.IRepository;

import javax.inject.Singleton;

import dagger.Component;

@Singleton
@Component(modules = {AppModule.class, NetModule.class})
public interface AppComponent {

    void inject(HackerApp hackerApp);
    Context context();

    IRepository repository();

}
