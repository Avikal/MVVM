package com.workpulse.hackernewsapp.ui;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import com.workpulse.hackernewsapp.util.LogUtil;

import io.reactivex.disposables.CompositeDisposable;

public abstract class BaseViewModel<N> extends ViewModel {

    public MutableLiveData<Boolean> liveDataIsLoading;

    public CompositeDisposable disposable = new CompositeDisposable();

    @Override
    public void onCleared() {
        super.onCleared();
        if (!disposable.isDisposed()) {
            disposable.dispose();
            LogUtil.e("BaseViewModel", "onCleared");
        }
    }

}
