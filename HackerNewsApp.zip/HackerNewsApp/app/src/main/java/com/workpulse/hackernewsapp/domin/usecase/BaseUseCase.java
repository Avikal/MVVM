package com.workpulse.hackernewsapp.domin.usecase;

import io.reactivex.Observable;

public abstract class BaseUseCase<PARAM, RESULT> {

    public Observable<RESULT> execute(PARAM param) {
        return createUsesCase(param);
    }

    public abstract Observable<RESULT> createUsesCase(PARAM param);

}

