package com.workpulse.hackernewsapp.domin.repository;

import com.workpulse.hackernewsapp.data.source.remote.model.NewsResponse;

import java.util.List;

import io.reactivex.Observable;

public interface IRepository {

    Observable<List<Integer>> getStories();

    Observable<NewsResponse> getHackerNews(int id);
}
