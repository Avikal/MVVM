package com.workpulse.hackernewsapp.ui.news;

import android.databinding.DataBindingUtil;
import android.os.Bundle;

import com.workpulse.hackernewsapp.R;
import com.workpulse.hackernewsapp.databinding.ActivityHackNewsBinding;
import com.workpulse.hackernewsapp.ui.BaseActivity;
import com.workpulse.hackernewsapp.ui.GlobalViewModelFactory;

import javax.inject.Inject;

public class HackNewsActivity extends BaseActivity {

    private ActivityHackNewsBinding binding;

    @Inject
    GlobalViewModelFactory<HackNewsViewModel> viewModelFactory;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this,
                R.layout.activity_hack_news);
    }
}
