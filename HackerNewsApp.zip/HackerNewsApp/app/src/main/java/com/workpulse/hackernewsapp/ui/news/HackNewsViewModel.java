package com.workpulse.hackernewsapp.ui.news;

import android.arch.lifecycle.MutableLiveData;

import com.workpulse.hackernewsapp.domin.usecase.NewsIdCase;
import com.workpulse.hackernewsapp.ui.BaseViewModel;

import java.util.List;

import javax.inject.Inject;

public class HackNewsViewModel extends BaseViewModel {

    public MutableLiveData<List<Integer>> getArticleId = new MutableLiveData();

    private NewsIdCase newsIdCase;
    private List<Integer> newsIds;
    @Inject
    public HackNewsViewModel(NewsIdCase newsIdCase,List<Integer> newsId)
    {
        this.newsIdCase = newsIdCase;
        this.newsIds = newsId;
    }

}
