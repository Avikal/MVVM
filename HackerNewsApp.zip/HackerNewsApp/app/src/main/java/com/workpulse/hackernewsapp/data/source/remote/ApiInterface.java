package com.workpulse.hackernewsapp.data.source.remote;


import com.workpulse.hackernewsapp.data.source.remote.model.NewsResponse;

import java.util.List;

import io.reactivex.Observable;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface ApiInterface {

    String BASE_URL = "https://hacker-news.firebaseio.com/";

    @GET("v0/topstories.json?print=pretty")
    Observable<List<Integer>> getTopStories();

    @GET("v0/item/{articleid}.json?print=pretty")
    Observable<NewsResponse> getNewsStories(@Path("articleid") int id);
}
