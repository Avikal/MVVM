package com.workpulse.hackernewsapp.domin.usecase;

import com.workpulse.hackernewsapp.domin.repository.IRepository;

import java.util.List;

import javax.inject.Inject;

import io.reactivex.Observable;
import io.reactivex.Scheduler;

public class NewsIdCase extends BaseUseCase<Integer, List<Integer>> {

    private IRepository iRepository;
    Scheduler observerOn;
    Scheduler subscriberOn;

    @Inject
    public NewsIdCase(IRepository repository, Scheduler observerOn,
                      Scheduler subscriberOn)
    {

        this.iRepository = repository;
        this.observerOn = observerOn;
        this.subscriberOn = subscriberOn;
    }
    @Override
    public Observable<List<Integer>> createUsesCase(Integer integer) {
        return iRepository.getStories().subscribeOn(subscriberOn).observeOn(observerOn);
    }
}
