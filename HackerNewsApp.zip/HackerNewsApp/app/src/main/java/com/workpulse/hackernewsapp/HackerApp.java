package com.workpulse.hackernewsapp;

import android.content.Context;
import android.support.multidex.MultiDex;
import android.support.multidex.MultiDexApplication;

import com.workpulse.hackernewsapp.data.source.remote.ApiInterface;
import com.workpulse.hackernewsapp.di.components.AppComponent;
import com.workpulse.hackernewsapp.di.components.DaggerAppComponent;
import com.workpulse.hackernewsapp.di.module.AppModule;
import com.workpulse.hackernewsapp.di.module.NetModule;

public class HackerApp extends MultiDexApplication {

    public static HackerApp instance;
    private AppComponent appComponent;

    public static HackerApp getInstance() {
        return instance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        createInjector();
        appComponent.inject(this);
    }

    @Override
    public void attachBaseContext(Context context) {
        super.attachBaseContext(context);
        MultiDex.install(context);
    }

    public void createInjector() {
        appComponent = DaggerAppComponent.builder()
                .appModule(new AppModule(this)).netModule(new NetModule(ApiInterface.BASE_URL)).build();
    }
}
