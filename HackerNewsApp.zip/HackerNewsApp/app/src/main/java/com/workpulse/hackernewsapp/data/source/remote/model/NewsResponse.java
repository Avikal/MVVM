package com.workpulse.hackernewsapp.data.source.remote.model;

public class NewsResponse {
}
