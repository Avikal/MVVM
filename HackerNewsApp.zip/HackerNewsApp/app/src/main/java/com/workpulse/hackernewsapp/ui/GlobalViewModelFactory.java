package com.workpulse.hackernewsapp.ui;

import android.arch.lifecycle.ViewModel;
import android.arch.lifecycle.ViewModelProvider;
import android.util.Log;

import javax.inject.Inject;

public class GlobalViewModelFactory<T> implements ViewModelProvider.Factory {


    private static final String TAG = GlobalViewModelFactory.class.getSimpleName();
    public T viewModel;


    @Inject
    GlobalViewModelFactory(T viewModel) {
        this.viewModel=viewModel;
    }

    @Override
    public <T extends ViewModel> T create(Class<T> modelClass) {
        Log.e(TAG, "create: " );
        return (T) viewModel;

    }
}