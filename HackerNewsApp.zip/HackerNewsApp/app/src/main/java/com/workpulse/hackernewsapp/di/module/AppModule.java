package com.workpulse.hackernewsapp.di.module;

import android.content.Context;

import com.workpulse.hackernewsapp.HackerApp;
import com.workpulse.hackernewsapp.data.Repository;
import com.workpulse.hackernewsapp.data.source.remote.ApiInterface;
import com.workpulse.hackernewsapp.domin.repository.IRepository;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;
import io.reactivex.Scheduler;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

@Module
public class AppModule {

    private HackerApp hackerApp;

    public AppModule(HackerApp hackerApp) {
        this.hackerApp = hackerApp;
    }

    @Provides
    @Singleton
    public Context provideContext() {
        return hackerApp;
    }

    @Provides
    @Singleton
    public Scheduler provideSubscriberThread() {
        return Schedulers.io();
    }

    @Provides
    @Singleton
    public Scheduler provideObserverThread() {
        return AndroidSchedulers.mainThread();
    }


    @Provides
    @Singleton
    public IRepository provideRepository(ApiInterface apiInterface) {
        return new Repository(apiInterface);
    }
}
